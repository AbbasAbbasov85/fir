let form = document.getElementById("form")
let name = document.getElementById("name")
let lastName = document.getElementById("lastname")
let email = document.getElementById("email")
let subject = document.getElementById("subject")
let textarea = document.getElementById("message")

async function postForm() {
    try {
      const response = await fetch("https://655c839c25b76d9884fd6e12.mockapi.io/Namiq", {
        method: "POST", 
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({

        firstname: firstname.value ,
        name: lastname.value ,
        email: email.value ,
        subject: subject.value ,
        textarea: textarea.value
        })

      });
  
      const result = await response.json();
      console.log("Success:", result);
    } catch (error) {
      console.error("Error:", error);
    }
  }
  
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    postForm();
})


let tocard = document.getElementById('tocard');
let loadBtn = document.getElementById('loadBtn');
let search = document.getElementById('search');


let page = 1;
let limit = 3;

const renderData = async () => {
    const response = await axios.get(`https://655c839c25b76d9884fd6e12.mockapi.io/Cefer?page=${page}&limit=${limit}`)
    const data = response.json
    console.log(data);
    db = data;
    db.forEach(item => {
        let cart = document.createElement('div')
        cart.className = "cart"
        cart.innerHTML = `
        <img src="${item.image}" alt="">
        <h3>${item.name}</h3>
        <p>${item.describtoin}</p>
        <button onclick="addToBasket(${item.id})">$ ${item.price}</button>
        `;
        tocard.appendChi(cart)
    });
    page++
}

renderData()


const searchByName = async (name) => {

    const res = await axios.get(`https://655c839c25b76d9884fd6e12.mockapi.io/Cefer`)
    const data = res.json
    console.log(data);
    let flteddata = data.filter(item => item.name.toLowerCase().includes(name))
    container.innerHTML = ""
    flteddata.forEach(item => {
        let cart = document.createElement('div')
        cart.className = "cart"
        cart.innerHTML = `
        <img src="${item.image}" alt="">
        <h3>${item.name}</h3>
        <p>${item.description}</p>
        <button>$ ${item.price}</button>
        `;
        tocard.appendChild(cart)
    });

}




function addToBasket(id) {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    cart.push(db.find((item) => item.id == id));
    localStorage.setItem("cart", JSON.stringify(cart));
}